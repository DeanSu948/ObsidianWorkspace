#!/usr/bin/env python3
import sys
import socket
import threading
import time
import re
import struct
import random
from urllib.parse import urlparse

class ProxyServer:
    def __init__(self, listen_port, fake_ip, dns_server_port, alpha):
        self.listen_port = listen_port
        self.fake_ip = fake_ip
        self.dns_server_port = dns_server_port
        self.alpha = alpha
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_socket.bind(('0.0.0.0', self.listen_port))
        self.server_socket.listen(5)
        self.throughput_estimates = {}
        self.log_file = open("log1.txt", "a")
        #self.server_socket.settimeout(10)  # Set timeout to prevent hanging

    def start(self):
    	print(f"Proxy server running on port {self.listen_port}")
    	while True:
        	client_socket, client_address = self.server_socket.accept()
        	print(f"Accepted connection from {client_address}")
        	threading.Thread(target=self.handle_client, args=(client_socket,)).start()

    def handle_client(self, client_socket):
        print("Client connected")
        try:
            client_socket.settimeout(10)  # Prevent client_socket from hanging
            request = client_socket.recv(4096)
            print("Request received:", request)
        
            if not request:
                print("No data in request; closing connection.")
                client_socket.close()
                return

            url = self.get_url_from_request(request)
            print("Parsed URL:", url)
        
            if url:
                self.forward_request(client_socket, url, request)
            else:
                print("URL parsing failed; closing connection.")
                client_socket.close()
        except Exception as e:
            print(f"Error handling client request: {e}")
            client_socket.close()

    def get_url_from_request(self, request):
        try:
            lines = request.decode().split('\r\n')
            method, path, _ = lines[0].split(' ')
            if method == 'CONNECT':
                return f'https://{path}'
            elif method in ['GET', 'POST', 'PUT', 'DELETE']:cc
                host = [line for line in lines if line.startswith('Host:')][0]
                host = host.split(':')[1].strip()
                return f'http://{host}{path}'
        except Exception as e:
            print(f"Error parsing request: {e}")
        return None

    def resolve_domain(self, domain):
        print(f"Attempting to resolve domain: {domain}")
        
        transaction_id = struct.pack("!H", random.randint(0, 65535))
        flags = b'\x01\x00'
        qdcount = b'\x00\x01'
        ancount = b'\x00\x00'
        nscount = b'\x00\x00'
        arcount = b'\x00\x00'

        query = b''
        for part in domain.split('.'):
            query += bytes([len(part)]) + part.encode()
        query += b'\x00'

        qtype = b'\x00\x01'  # Type A
        qclass = b'\x00\x01'  # Class IN

        dns_request = transaction_id + flags + qdcount + ancount + nscount + arcount + query + qtype + qclass

        dns_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        dns_socket.sendto(dns_request, ('127.0.0.1', self.dns_server_port))

        data, _ = dns_socket.recvfrom(512)
        dns_socket.close()

        if data[3] & 15 == 0 and struct.unpack("!H", data[6:8])[0] > 0:
            ip_start = -4
            server_ip = socket.inet_ntoa(data[ip_start:])
            print(f"Resolved domain {domain} to IP {server_ip}")
            return server_ip
        else:
            print(f"Failed to resolve domain {domain}")
            return None

    def forward_request(self, client_socket, url, request):
        parsed_url = urlparse(url)
        domain = parsed_url.hostname
        client_ip = client_socket.getpeername()[0]

        server_ip = self.resolve_domain(domain)
        if server_ip is None:
            print("Could not resolve domain; closing connection.")
            client_socket.close()
            return

        available_bitrates = self.get_available_bitrates(server_ip)
        print(f"Forwarding request to {server_ip}:{parsed_url.port or 80}")

        try:
            remote_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            remote_socket.settimeout(10)  # Timeout for remote server connection
            remote_socket.connect((server_ip, parsed_url.port or 80))
            remote_socket.sendall(request)

            start_time = time.time()
            response = remote_socket.recv(4096)
            total_response_size = len(response)
            while response:
                client_socket.send(response)
                response = remote_socket.recv(4096)
                total_response_size += len(response)
            end_time = time.time()

            smoothed_throughput = self.calculate_throughput(start_time, end_time, total_response_size, client_ip, server_ip)

            selected_bitrate = self.select_bitrate(smoothed_throughput, available_bitrates)
            modified_request = self.modify_request_uri(request, selected_bitrate)

            self.log_request(start_time, end_time, smoothed_throughput, selected_bitrate, server_ip, modified_request)
            print("Request logged successfully.")

        except Exception as e:
            print(f"Error forwarding request: {e}")
        finally:
            remote_socket.close()
            client_socket.close()

    def calculate_throughput(self, start_time, end_time, chunk_size, client_ip, server_ip):
        duration = end_time - start_time
        throughput = (chunk_size * 8) / duration
        key = (client_ip, server_ip)
        if key not in self.throughput_estimates:
            self.throughput_estimates[key] = throughput
        else:
            current_throughput = self.throughput_estimates[key]
            smoothed_throughput = (self.alpha * throughput) + ((1 - self.alpha) * current_throughput)
            self.throughput_estimates[key] = smoothed_throughput
        return self.throughput_estimates[key]

    def select_bitrate(self, smoothed_throughput, available_bitrates):
        for bitrate in sorted(available_bitrates, reverse=True):
            if smoothed_throughput >= (bitrate * 1.5):
                return bitrate
        return min(available_bitrates)

    def get_available_bitrates(self, server_ip):
        return [45514, 176827, 506300, 1006743]

    def modify_request_uri(self, request, selected_bitrate):
        request = re.sub(r'bunny_\d+bps', f'bunny_{selected_bitrate}bps', request.decode())
        return request.encode()

    def log_request(self, start_time, end_time, smoothed_throughput, selected_bitrate, server_ip, chunk_name):
        if isinstance(chunk_name, bytes):
            chunk_name = chunk_name.decode().split(" ")[1]

        duration = end_time - start_time
        throughput_kbps = smoothed_throughput / 1000
        avg_throughput_kbps = smoothed_throughput / 1000
        chunk_bitrate_kbps = selected_bitrate / 1000

        log_entry = f"{int(time.time())} {duration:.6f} {throughput_kbps:.12f} {avg_throughput_kbps:.12f} {chunk_bitrate_kbps:.0f} {server_ip} {chunk_name}\n"
        self.log_file.write(log_entry)
        self.log_file.flush()

if __name__ == '__main__':
    listen_port = 8000
    fake_ip = '1.0.0.1'
    dns_server_port = 53
    alpha = 0.5

    proxy = ProxyServer(listen_port, fake_ip, dns_server_port, alpha)
    proxy.start()
